let numberСalls = 3;
let errorString = "Все корректно введено товары сейчас загрузятся";

//Прелоадер загрузки товаров
let preloader = document.createElement('div');
preloader.textContent = "Подождите идет загрузка товаров...";
document.body.append(preloader);




//запрос списка товаров
async function loadProducts() {
  //запрашиваем список товаров
  let response = await fetch('/api/products/');
  drawingError(response)
  let result = await response.json();
  //console.log(result);
  return result;
}

//отрисовываем ошибки
function drawingError(response) {

  if (response.status === 200) {
    errorString = "Все корректно введено товары сейчас загрузятся";
    showModalWindow(errorString)
  }
  if (response.status === 404) {
    errorString = "Каталог товаров пуст";
    showModalWindow(errorString)
    let emptytitle = document.createElement('h2')
    emptytitle.innerHTML = "Список товаров пуст"
    document.body.append(emptytitle)


  }

  //console.log(Number(numberСalls))
  if ((response.status === 500)) {
    numberСalls -= 1;
    if(numberСalls===0){
    errorString = "Произошла ошибка, попробуйте обновить страницу позже";
    showModalWindow(errorString)
    alert("Произошла ошибка, попробуйте обновить страницу позже")
    }
    else{
    return loadProducts();
    }
  }
  if (response.json_invalid) {
    errorString = "Произошла ошибка, попробуйте обновить страницу позже";
    showModalWindow(errorString)
  }
  setTimeout(closeModalWindow, 3000);
}


//получам список товаров запросом по API
loadProducts().then(item => {
  //console.log(item.products);

  //выводим список товаров
  item.products?.forEach((el) => {

    let title = document.createElement('h3');
    title.innerHTML = el.name;
    document.body.append(title);

    let price = document.createElement('h3');
    price.innerHTML = el.price;
    document.body.append(price);

    let img = document.createElement('img');
    img.src = el.image;
    img.style.width = "100px";
    img.style.height = "100px";
    document.body.append(img);
    preloader.style.display = "none";

  })
})





//cоздаем модальное окно
function showModalWindow(errorString) {
  let modalWindow = document.createElement('div');
  modalWindow.id = "modalwindow";
  modalWindow.style.width = "300px";
  modalWindow.style.height = "50px";
  modalWindow.style.position = "fixed";
  modalWindow.style.backgroundColor = "#D3D3D3";
  modalWindow.style.marginLeft = "1000px";
  modalWindow.style.marginTop = "500px";
  modalWindow.textContent = errorString;
  document.body.append(modalWindow);

}

//Скрываем модальное окно
function closeModalWindow() {
  modalwindow = document.getElementById("modalwindow");
  if (modalwindow) {
    modalwindow.style.display = "none";
  }
}
