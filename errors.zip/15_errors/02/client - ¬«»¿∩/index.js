let numberСalls = 3;
let errorString = "Все корректно подождите сейчас товары появятся"
//Прелоадер загрузки товаров
let preloader = document.createElement('div');
preloader.textContent = "Подождите идет загрузка товаров...";
document.body.append(preloader);




//запрос списка товаров
async function loadProducts() {
  if (numberСalls === 0) {
    alert("Произошла ошибка, попробуйте обновить страницу позже");
    return;
  }

  let response = await fetch('/api/products/?status=404');
  if (response.status === 404)  {
    emptytitle = document.createElement('h2')
    emptytitle.innerHTML = "Список товаров пуст"
    document.body.append(emptytitle)
   
  }
  if (response.status === 500) {
    numberСalls -= 1;
    errorString = "Произошла ошибка, попробуйте обновить страницу позже";
    showModalWindow(errorString)
    return loadProducts();
  }
  if (response.json_invalid = true) {
    let errorString = "Произошла ошибка, попробуйте обновить страницу позже";
    showModalWindow(errorString);
  }
  let result = await response.json();
  console.log(result);
  return result;
}



//получам список товаров запросом по API
loadProducts().then(item => {
  console.log(item.products);

  //выводим список товаров
  item.products.forEach((el) => {

    let title = document.createElement('h3');
    title.innerHTML = el.name;
    document.body.append(title);

    let price = document.createElement('h3');
    price.innerHTML = el.price;
    document.body.append(price);

    let img = document.createElement('img');
    img.src = el.image;
    img.style.width = "100px";
    img.style.height = "100px";
    document.body.append(img);
    preloader.style.display = "none";
  })
})





//cоздаем модальное окно
function showModalWindow(errorString) {
  let modalWindow = document.createElement('div');
  modalWindow.id = "modalwindow";
  modalWindow.style.width = "300px";
  modalWindow.style.height = "50px";
  modalWindow.style.position = "fixed";
  modalWindow.style.backgroundColor = "#D3D3D3";
  modalWindow.style.marginLeft = "1000px";
  modalWindow.style.marginTop = "500px";
  modalWindow.textContent = errorString;
  document.body.append(modalWindow);

}

//Скрываем модальное окно
function closeModalWindow() {
  modalwindow = document.getElementById("modalwindow");
  modalwindow.style.display = "none";
}

setTimeout(closeModalWindow, 3000);

//показываем модальное окно
showModalWindow(errorString)
