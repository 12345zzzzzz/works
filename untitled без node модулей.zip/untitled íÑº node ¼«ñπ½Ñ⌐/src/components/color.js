export default[
    {id:1,
    code:'#73B6EA'
    },
    {id:2,
        code:'#FFBE15'
    },
    {id:3,
        code:'#939393'
    },
    {id:4,
        code:'#8BE000'
    },
    {id:5,
        code:'#FF6B00'
    },
    {id:6,
        code:'#FFFFFF'
    },
    {id:7,
        code:'#000000'
    },



]