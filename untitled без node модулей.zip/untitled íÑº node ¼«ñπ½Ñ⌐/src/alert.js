import data from './data'






function ShowMessage(){
alert(data.message);
alert(data.message2);}

export default ShowMessage;