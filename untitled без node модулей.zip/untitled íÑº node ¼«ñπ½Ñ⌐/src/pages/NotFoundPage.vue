<template>
    <h1>Cтраница не найдена</h1>
</template>

<script>
    export default {}

</script>