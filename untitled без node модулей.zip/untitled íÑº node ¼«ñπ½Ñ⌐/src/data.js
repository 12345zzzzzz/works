const data={
  message:'Привет Vue!',
  message2:'Hello Vue!'
}

export default  data;
